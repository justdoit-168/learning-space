###
 # @Date           : 2021-04-28 01:24:07
 # @FilePath       : /jinnian-space/z-sh/cp.sh
 # @Description    : 
### 

# 
 cp m1.vue m2.vue
 cp m1.vue m3.vue
 cp m1.vue m4.vue
 cp m1.vue m5.vue
 cp m1.vue m6.vue
 cp m1.vue m7.vue
 
 





