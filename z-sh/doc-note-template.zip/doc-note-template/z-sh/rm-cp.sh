###
 # @Date           : 2021-07-04 19:04:38
 # @FilePath       : /jinnian-space/z-sh/rm-cp.sh
 # @Description    : 
### 


rm -r ./public/fonts/* ; cp -r ./docs-2/fonts/*  ./public/fonts/


rm -r ./public/css/* ; cp -r ./docs-2/css/*  ./public/css/


rm -r ./public/js/* ; cp -r ./docs-2/js/*  ./public/js/
