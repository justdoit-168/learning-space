// import something here

// "async" is optional;
// more info on params: https://quasar.dev/quasar-cli/boot-files


import Vue from 'vue'
import lodash from "lodash"

Vue.prototype.$lodash  = lodash 