/*
 * @Date           : 2020-08-31 16:40:04
 * @FilePath       : /jinnian-space/src/config/note/record.js
 * @Description    :
 */
export default [
  { date: "2020-11-12 23:06:51", note: "更改C端目录  flutter 学习 开始  " },
  { date: "2020-10-31 23:43:29", note: "改善 各端头部输出配置  " },
  { date: "2020-10-31 08:26:35", note: "加入  electron构建，升级脚手架，追加书籍" },
  { date: "2020-10-28 08:25:52", note: "linux  加入书籍" },
  { date: "2020-10-26 21:27:41", note: "书架 加入书籍" },
  { date: "2020-10-26 00:34:16", note: "书架 加入书籍" },
  { date: "2020-10-23 03:04:00", note: "书架 加入书籍" },
  { date: "2020-10-10 02:41:11", note: "node   加入 全栈项目依赖" },
  { date: "2020-10-10 02:32:16", note: "linux   加入 shell 基础" },
  { date: "2020-08-29 02:15:49", note: "web  css 加入 SASS总结" },
  { date: "2020-08-29 01:31:47", note: "linux 加入部分内容" }
];
