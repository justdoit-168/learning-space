# 笔记模板项目说明

建议 nodejs  14.18 版本 

运行项目 步骤：
第一步：需要先安装 nodejs  14.18 版本 
第二步：然后  [安装 quasar 脚手架](https://v1.quasar.dev/quasar-cli/installation)
第三步：安装 git [git](https://git-scm.com/)
第三步：项目根目录内 安装依赖   npm i 
第四步：本地启动运行项目：  quasar  dev 

项目构建 步骤：
第一步： 根目录运行，命令 ： npm run bg 
第二步： 上传gitHub   ,推荐 github 自己的 桌面软件  [GitHub Desktop](https://desktop.github.com/)
        也可以上传国内的 gitee   

项目发布步骤：
     gitHub       gitee  上面 针对项目都可以设置 主页 ， 设置了就相当于发布了 


### Customize the configuration
See [Configuring quasar.conf.js](https://v1.quasar.dev/quasar-cli/quasar-conf-js).
